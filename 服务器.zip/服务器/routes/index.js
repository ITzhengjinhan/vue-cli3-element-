﻿var express=require('express');
var router=express.Router();
// 引入数据库配置文件
const db = require('./database')

 router.get('/hotactivity', (req, res) => {
    let phonenumber=req.query.phonenumber
    let scene_id=req.query.scene_id
    console.dir(req.query)
    let sql='select a.scene_id,s.scene_name,s.img from apply a,scene s where a.scene_id=s.scene_id group by a.scene_id  ORDER BY count(a.scene_id) desc'

    db.query(sql, (err, result) => {
        // ----------res：API传数据
        // ----------result：返回的数据，需要转成JSON格式、

        res.json(result); 
    }); 
  }) 

router.get('/scene', (req, res) => {
    let id=req.query.scene_id
    console.dir(req.query)
    let sql=''
    if(id==null){
    sql='SELECT * FROM scene' 
    }
    else{
    sql = `SELECT  s.* ,COUNT(apply_id)FROM apply a, scene s 
    where a.scene_id=s.scene_id and a.scene_id=`+id;
}
    db.query(sql, (err, result) => {
        // ----------res：API传数据
        // ----------result：返回的数据，需要转成JSON格式、

        //-----------修改数据库获取出来的键值对中的键
        let key=['scene_id','scene_name','scene_desc','scene_address','scene_detail','img','start_time','end_time','maxnumber','peoplenum'];
        let newArr=[];
        result.forEach((item,index)=>{
            let newobj={};
            for(var i=0;i<key.length;i++){
                newobj[key[i]]=item[Object.keys(item)[i]]
            }
            newArr.push(newobj);
        })
        console.dir(newArr)
        res.json(newArr); 
    }); 
  }) 

	router.post('/adduser', (req, res) => {
		console.log(req.body.name)
		var wx_name="'"+req.body.wx_name+"'";
		var wx_gender="'"+req.body.wx_gender+"'";
		var wx_address="'"+req.body.wx_address+"'";
		var phonenumber=req.body.phonenumber;
		let sql=`INSERT INTO user(phonenumber,wx_name,wx_gender,wx_address) VALUES(`
    +phonenumber+','+wx_name+','+wx_gender+','+wx_address+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }        
       console.log(result);        
    });
  })
/*
  router.get('/adduser', (req, res) => {
    console.dir(req.query)
    var wx_name="'"+req.query.wx_name+"'";
    var wx_gender="'"+req.query.wx_gender+"'";
    var wx_address="'"+req.query.wx_address+"'";
    var phonenumber=req.query.phonenumber;
    let sql=`INSERT INTO user(phonenumber,wx_name,wx_gender,wx_address) VALUES(`
    +phonenumber+','+wx_name+','+wx_gender+','+wx_address+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }        
       console.log(result);        
    });
  })*/
  
//判断预约情况
  router.get('/isapply', (req, res) => {
    let phonenumber=req.query.phonenumber
    let scene_id=req.query.scene_id
    console.dir(req.query)
    let sql='SELECT * FROM apply where phonenumber=' +phonenumber+' and scene_id='+scene_id

    db.query(sql, (err, result) => {
        // ----------res：API传数据
        // ----------result：返回的数据，需要转成JSON格式、

        res.json(result); 
    }); 
  }) 

//申请预约
  router.get('/addapply', (req, res) => {
    console.dir(req.query)
    var scene_id=req.query.scene_id
    var phonenumber=req.query.phonenumber;
    let sql=`INSERT INTO apply(scene_id,isapply,phonenumber) VALUES(`
    +scene_id+','+1+','+phonenumber+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })

  router.get('/deleteapply', (req, res) => {
    console.dir(req.query)
    var scene_id=req.query.scene_id
    var phonenumber=req.query.phonenumber;
    let sql=`DELETE FROM apply where scene_id=`+scene_id+' and phonenumber='+phonenumber
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
//修改键值对中的值
 router.get('/queryapply', (req, res) => {
    let phonenumber=req.query.phonenumber
    console.dir(req.query)
    let sql=`select b.*,a.isapply from apply a,scene b where a.scene_id=b.scene_id and phonenumber=`+phonenumber

    db.query(sql, (err, result) => {
		for(let i=0;i<result.length;i++){
			if(result[i].isapply==1){
				result[i].isapply='取消报名'
			}else if(result[i].isapply==0){
				result[i].isapply='报名失败'
			}
		}
		console.log(result)
        res.json(result); 
    }); 
  })

  router.get('/phonenumberisexsist', (req, res) => {
    console.dir(req.query)
	 var wx_name="'"+req.query.wx_name+"'";
    var phonenumber=req.query.phonenumber;
    let sql='SELECT * FROM user where phonenumber=' +phonenumber+' and wx_name='+wx_name
    db.query(sql, (err, result) => {
		console.log(result)
      if(result!=''&& phonenumber!=''){
        res.json({status:'ok'})
      }else{
        res.json({status:'error'}); }
    }); 
  }) 

  router.get('/addcollect', (req, res) => {
    console.dir(req.query)
    var model1="'"+req.query.model1+"'";
    var model2="'"+req.query.model2+"'";
    var model3="'"+req.query.model3+"'";
    var model4="'"+req.query.model4+"'";
    var model5="'"+req.query.model5+"'";
    var model6="'"+req.query.model6+"'";
    var model7="'"+req.query.model7+"'";
    var model8="'"+req.query.model8+"'";
    var model9="'"+req.query.model9+"'";
    var phonenumber=req.query.phonenumber;
    let sql=`INSERT INTO collect(model1,model2,model3,model4,model5,model6,model7,model8,model9,phonenumber) VALUES(`
    +model1+','+model2+','+model3+','+model4+','+model5+','+model6+','+model7+','+model8+','+model9+','+phonenumber+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         res.json({status:'error'})  
         return;
        }   // http://localhost:3000/addcollect?model1=0&&model2=0&&model3=0&&model4=0&&model5=0&&model6=0&&model7=0&&model8=0&&model9=0&&phonenumber=18344995466       
       res.json({status:'ok'})    
    });
  })

  router.get('/collect', (req, res) => {
    console.dir(req.query)
    var phonenumber=req.query.phonenumber;
    let sql='SELECT * FROM collect where phonenumber=' +phonenumber
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 

  router.get('/updatecollect', (req, res) => {
    console.dir(req.query)
    var model1="'"+req.query.model1+"'";
    var model2="'"+req.query.model2+"'";
    var model3="'"+req.query.model3+"'";
    var model4="'"+req.query.model4+"'";
    var model5="'"+req.query.model5+"'";
    var model6="'"+req.query.model6+"'";
    var model7="'"+req.query.model7+"'";
    var model8="'"+req.query.model8+"'";
    var model9="'"+req.query.model9+"'";
    var phonenumber=req.query.phonenumber;
    let sql=`update collect set model1=`+model1+',model2='+model2+',model3='+model3+',model4='
    +model4+',model5='+model5+',model6='+model6+',model7='+model7+',model8='+model8+',model9='+model9+' where phonenumber='+phonenumber; 
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[update ERROR] - ',err.message);
         res.json({status:'error'})  
         return;
        }         
       res.json({status:'ok'})    
    });
  })
  
  router.get('/getexhibit', (req, res) => {
    let sql='SELECT * FROM museum'

    db.query(sql, (err, result) => {
        // ----------res：API传数据
        // ----------result：返回的数据，需要转成JSON格式、

        res.json(result); 
    }); 
  }) 
  module.exports = router;

