﻿var express=require('express');
var router=express.Router();
const db = require('./database')
router.get('/outdex',function(req,res,next){
    res.send('outdex');
})
//---------------------景区模块
//第pageindex页显示pagesize多数据
 router.get('/pagingqueryscene', (req, res) => {
	var pagesize=req.query.pagesize;
	var pageindex=(req.query.pageindex-1)*pagesize
    console.dir(req.query)
    let sql='SELECT * FROM scene limit '+pageindex+','+pagesize
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
   router.get('/queryscenenumber', (req, res) => {
    let sql='SELECT count(1) as count FROM scene' 
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  router.get('/queryapplynumber', (req, res) => {
	      let sql=`select count(scene_id) as number from apply group by scene_id `
		      db.query(sql, (err, result) => {
				        if(result==''){
							        res.json({status:'error'})
						}else{
						res.json(result); }
			  }); 
  }) 
    
	  router.get('/queryscene_name', (req, res) => {
		      let sql='select scene_name from scene '
			      db.query(sql, (err, result) => {
					        if(result==''){
								        res.json({status:'error'})
							}else{
							res.json(result); }
				  }); 
	  })
  
   router.get('/deletescene', (req, res) => {
    console.dir(req.query)
    var scene_id=req.query.scene_id
    let sql=`DELETE FROM scene  where scene_id=`+scene_id
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/editscene', (req, res) => {
    console.dir(req.query)
	var scene_id=req.query.scene_id
    var scene_name="'"+req.query.scene_name+"'"
	var scene_desc="'"+req.query.scene_desc+"'"
	var scene_address="'"+req.query.scene_address+"'"
	var scene_detail="'"+req.query.scene_detail+"'"
	var img="'"+req.query.img+"'"
	var start_time="'"+req.query.start_time+"'"
	var end_time="'"+req.query.end_time+"'"
	var maxnumber="'"+req.query.maxnumber+"'"
    let sql=`update scene set scene_name=`+scene_name+',scene_desc='+scene_desc+',scene_address='+scene_address+',scene_detail='
    +scene_detail+',img='+img+',start_time='+start_time+',end_time='+end_time+',maxnumber='+maxnumber +' where scene_id='+scene_id; 
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })//http://localhost:3000/editscene?scene_name=test&&scene_desc=test&&scene_detail=test&&img=test&&start_time=test&&end_time=test&&maxnumber=test&&scene_id=1
  
  router.get('/addscene', (req, res) => {
    console.dir(req.query)
    var scene_name="'"+req.query.scene_name+"'"
	var scene_desc="'"+req.query.scene_desc+"'"
	var scene_address="'"+req.query.scene_address+"'"
	var scene_detail="'"+req.query.scene_detail+"'"
	var img="'"+req.query.img+"'"
	var start_time="'"+req.query.start_time+"'"
	var end_time="'"+req.query.end_time+"'"
	var maxnumber="'"+req.query.maxnumber+"'"
    let sql=`INSERT INTO scene(scene_name,scene_desc,scene_address,scene_detail,img,start_time,end_time,maxnumber) VALUES(`
    +scene_name+','+scene_desc+','+scene_address+','+scene_detail+','+img+','+start_time+','+end_time+','+maxnumber+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })//http://localhost:3000/addscene?scene_name=test&&scene_desc=test&&scene_detail=test&&img=test&&start_time=test&&end_time=test&&maxnumber=test
  
  //---------------------景区景点模块
  router.get('/pagingqueryscenic', (req, res) => {
    var pagesize=req.query.pagesize;
	var pageindex=(req.query.pageindex-1)*pagesize
    console.dir(req.query)
    let sql='SELECT * FROM scenic limit '+pageindex+','+pagesize
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  router.get('/queryscenicnumber', (req, res) => {
    let sql='SELECT count(1) as count FROM scenic' 
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  
  
   router.get('/deletescenic', (req, res) => {
    console.dir(req.query)
    var scenic_id=req.query.scenic_id
    let sql=`DELETE FROM scenic  where scenic_id=`+scenic_id
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/editscenic', (req, res) => {
    console.dir(req.query)
	var scenic_id=req.query.scenic_id
    var scenic_name="'"+req.query.scenic_name+"'"
	var scenic_desc="'"+req.query.scenic_desc+"'"
	var scenic_img="'"+req.query.scenic_img+"'"
	//var scene_detail="'"+req.query.scene_detail+"'"
	
    let sql=`update scenic set scenic_name=`+scenic_name+',scenic_desc='+scenic_desc+',scenic_img='+scenic_img+' where scenic_id='+scenic_id; 
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/addscenic', (req, res) => {
    console.dir(req.query)
   	 var scenic_id=req.query.scenic_id
    	var scenic_name="'"+req.query.scenic_name+"'"
	var scenic_desc="'"+req.query.scenic_desc+"'"
	var scenic_img="'"+req.query.scenic_img+"'"
    let sql=`INSERT INTO scenic(scenic_name,scenic_desc,scenic_img) VALUES(`
    +scenic_name+','+scenic_desc+','+scenic_img+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  //---------------------博物馆模块
  router.get('/pagingquerymuseum', (req, res) => {
    var pagesize=req.query.pagesize;
	var pageindex=(req.query.pageindex-1)*pagesize
    console.dir(req.query)
    let sql='SELECT * FROM museum limit '+pageindex+','+pagesize
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  router.get('/querymuseumnumber', (req, res) => {
    let sql='SELECT count(1) as count FROM museum' 
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  
  
   router.get('/deletemuseum', (req, res) => {
    console.dir(req.query)
    var exhibit_id=req.query.exhibit_id
    let sql=`DELETE FROM museum  where exhibit_id=`+exhibit_id
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/editmuseum', (req, res) => {
    console.dir(req.query)
	var exhibit_id=req.query.exhibit_id
    var exhibit_name="'"+req.query.exhibit_name+"'"
	var exhibit_info="'"+req.query.exhibit_info+"'"
	var exhibit_info_en="'"+req.query.exhibit_info_en+"'"
	var exhibit_img="'"+req.query.exhibit_img+"'"
	//var scene_detail="'"+req.query.scene_detail+"'"
	
    let sql=`update museum set exhibit_name=`+exhibit_name+',exhibit_info='+exhibit_info+',exhibit_info_en='+exhibit_info_en+',exhibit_img='+exhibit_img+' where exhibit_id='+exhibit_id; 
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/addmuseum', (req, res) => {
    console.dir(req.query)
   	 var exhibit_id=req.query.exhibit_id
    	var exhibit_name="'"+req.query.exhibit_name+"'"
	var exhibit_info="'"+req.query.exhibit_info+"'"
	var exhibit_info_en="'"+req.query.exhibit_info_en+"'"
	var exhibit_img="'"+req.query.exhibit_img+"'"
    let sql=`INSERT INTO museum(exhibit_name,exhibit_info,exhibit_info_en,exhibit_img) VALUES(`
    +exhibit_name+','+exhibit_info+','+exhibit_info_en+','+exhibit_img+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  //-------------------用户
  router.get('/pagingqueryuser', (req, res) => {
    var pagesize=req.query.pagesize;
	var pageindex=(req.query.pageindex-1)*pagesize
    console.dir(req.query)
    let sql='SELECT * FROM user limit '+pageindex+','+pagesize
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  router.get('/queryusernumber', (req, res) => {
    let sql='SELECT count(1) as count FROM user' 
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  router.get('/adminadduser', (req, res) => {
    console.dir(req.query)
    var wx_name="'"+req.query.wx_name+"'";
    var wx_gender="'"+req.query.wx_gender+"'";
    var wx_address="'"+req.query.wx_address+"'";
    var phonenumber="'"+req.query.phonenumber+"'";
    let sql=`INSERT INTO user(phonenumber,wx_name,wx_gender,wx_address) VALUES(`
    +phonenumber+','+wx_name+','+wx_gender+','+wx_address+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }        
       res.json({status:'ok'})          
    });
  })
  
   router.get('/deleteuser', (req, res) => {
    console.dir(req.query)
    var phonenumber=req.query.phonenumber
    let sql=`DELETE FROM user  where phonenumber=`+phonenumber
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
 
  router.get('/edituser', (req, res) => {
    console.dir(req.query)
	var phonenumber="'"+req.query.phonenumber+"'"
    var wx_name="'"+req.query.wx_name+"'"
	var wx_gender="'"+req.query.wx_gender+"'"
	var wx_address="'"+req.query.wx_address+"'"
	var yuanhaoma="'"+req.query.yuanhaoma+"'"
    let sql=`update user set phonenumber=`+phonenumber+',wx_name='+wx_name+',wx_gender='+wx_gender+',wx_address='+wx_address+' where phonenumber='+yuanhaoma; 
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  //------------------------收集
   router.get('/admindeletecollect', (req, res) => {
    console.dir(req.query)
    var phonenumber="'"+req.query.phonenumber+"'"
    let sql=`DELETE FROM collect  where phonenumber=`+phonenumber
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  //---------------------------活动报名
  
  router.get('/pagingqueryapply', (req, res) => {
    var pagesize=req.query.pagesize;
	var pageindex=(req.query.pageindex-1)*pagesize
    console.dir(req.query)
    let sql='SELECT apply.*,scene_name FROM apply,scene where apply.scene_id=scene.scene_id limit '+pageindex+','+pagesize
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  router.get('/queryapplynumbertotal', (req, res) => {
    let sql='SELECT count(1) as count FROM apply' 
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  router.get('/admineditapply', (req, res) => {
    console.dir(req.query)
	var apply_id=req.query.apply_id
    var scene_id=req.query.scene_id
	var isapply=req.query.isapply
	var phonenumber="'"+req.query.phonenumber+"'"
	
    let sql=`update apply set scene_id=`+scene_id+',isapply='+isapply+',phonenumber='+phonenumber+' where apply_id='+apply_id; 
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/adminaddapply', (req, res) => {
    console.dir(req.query)
   	var apply_id=req.query.apply_id
    var scene_id=req.query.scene_id
	var isapply=req.query.isapply
	var phonenumber="'"+req.query.phonenumber+"'"
    let sql=`INSERT INTO apply(scene_id,isapply,phonenumber) VALUES(`
    +scene_id+','+isapply+','+phonenumber+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
   router.get('/admindeleteapply', (req, res) => {
    console.dir(req.query)
    var phonenumber="'"+req.query.phonenumber+"'"
    let sql=`DELETE FROM apply  where phonenumber=`+phonenumber
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/admindeleteapplybyid', (req, res) => {
    console.dir(req.query)
    var apply_id=req.query.apply_id
    let sql=`DELETE FROM apply  where apply_id=`+apply_id
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/queryapplybyinput', (req, res) => {
	    console.dir(req.query)
		  var scene_name=req.query.scene_name    
		 let sql="SELECT apply.*,scene_name FROM apply,scene where apply.scene_id=scene.scene_id and apply.scene_id in(SELECT scene_id FROM scene where scene_name like '%"+scene_name+"%')"
		      db.query(sql, (err, result) => {
				        if(result==''){
							        res.json({status:'error'})
						}else{
							   console.dir(result)
						res.json(result); }
			  }); 
  })
  
module.exports=router;