﻿let express=require('express');
let https = require('https');
let http = require('http');
let fs = require('fs');

//执行express创建一个服务：返回结果app用来操作这个服务
let app=express();



 var options={
	 key:fs.readFileSync('./https/a.key'),
	 cert:fs.readFileSync('./https/a.pem')
 }

app.set('porthttps',process.env.PORT || 3000)
https.createServer(options,app).listen(app.get('porthttps'),function(){
	console.log("the port is runing："+app.get('porthttps'))
})

//传递参数
app.get('/profile/:id',function(req,res){
    res.send("ID:"+req.params.id)
});

//获取get？后面的参数值(req.query)
app.get('/getkv',function(req,res){
    res.send("key:"+req.query.k)
});

//获取post？后面的参数值(req.body)
app.post('/',function(req,res){
    console.dir(req.body)
    res.send("postname:"+req.body.name)
});

//创建一个WEB服务，监听端口号

//数据API请求的处理
//静态资源文件的请求处理
// app.use(express.static('./star'));
// app.use((req,res)=>{
// //执行static并没有找到对应的资源文件(我们可以做404处理)
//     res.status(404);
//     res.send('Not Found~~');
// });
/*Request对象（req）
*   req.path：存储请求地址的路径名称
*   req.query：存储问号传参的相关信息（对象）
*   req.body：在配合body-parser中间件的情况下，req.body存储的是请求主体传递过来的信息
*   req.method：请求方式
*   req.get：获取响应头信息

*RESPONSE对象（res）
*   res.end：结束响应并返回内容
*   res.json：返回给客户端内容，格式是JSON/字符串/BUFFER,响应主体返回给客户端信息
*   res.send：最常用的给客户端返回信息（可以传递对象/PATH/BUFFER）
*   res.status：返回状态码
*   res.set：设置相应头信息 res.set({KEY:VALUE,...})
*/




  var indexRouter=require('./routes/index')
  var outdexRouter=require('./routes/outdex')
 
  app.use(indexRouter);
  app.use(outdexRouter)

 
