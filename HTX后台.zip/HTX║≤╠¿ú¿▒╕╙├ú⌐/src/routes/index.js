import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

export default new VueRouter({
    routes:[
      {
        path:"/",
        /*  ./与@/的区别
        ./是相同目录下的不同路径访问
        @/是src目录下的路径
        */
       //路由懒加载：更高效
        component:()=>import ('@/view/login.vue')
        
      },
      {
        path:"/home",
		meta: {
			        requireAuth: true, 
		},
        component:()=>import ('@/view/home.vue'),
        children:[{
          path:"applyproject",
		  meta: {
			        requireAuth: true, 
		},
        component:()=>import ('@/view/applyproject.vue'),
        },
        {
        path:"museuminfo",
		meta: {
			        requireAuth: true, 
		},
        component:()=>import ('@/view/museuminfo.vue'),
        },
		{
        path:"scenicinfo",
		meta: {
			        requireAuth: true, 
		},
        component:()=>import ('@/view/scenicinfo.vue'),
        },
		{
          path:"index",
		  meta: {
			        requireAuth: true, 
		},
        component:()=>import ('@/view/index.vue'),
        }, {
          path:"user",
		  meta: {
			        requireAuth: true, 
		},
          component:()=>import ('@/view/user.vue'),
          },
          {
            path:"apply",
			meta: {
			        requireAuth: true, 
		},
            component:()=>import ('@/view/apply.vue'),
            }]
      }
    ]
   }) 