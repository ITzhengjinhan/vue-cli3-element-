<template>
  <div class="wrapper">
   <div style="margin-left:20em;margin-top:6vh;position:absolute"><h2>欢迎来到武洋花天下后台管理系统</h2></div>
	<div id="myChart" :style="{width: '1000px', height: '500px',marginLeft:'1em',marginTop:'20vh',position:'absolute'}"></div>
    </div>
</template>
<script>
export default {
  name: 'echarts',
  data () {
    return {
      scene_name:[],
	  applynumber:[]
    }
  },
  mounted(){
      setTimeout(()=>{
	        this.drawLine();
			    },1000)
			this.getdata();
  },
  methods: {
    drawLine(){
        // 基于准备好的dom，初始化echarts实例
        let myChart = this.$echarts.init(document.getElementById('myChart'))
        // 绘制图表
        myChart.setOption({
            title: { text: '报名项目人数' },
            tooltip: {},
            xAxis: [{
			 data: this.scene_name,
			axisLabel:{interval:0}
			 }],
            yAxis: {},
            series: [{
                name: '人数',
                type: 'bar',
                data: this.applynumber,
				 barWidth:40,
				 barGap:'80%',
				 barCategoryGap:'50%'
            }]
        });
    },
	getdata(){
	     var url="/queryscene_name"
	     fetch(url).then(res=>{
	   // this.tableData=res.data 
         return res.json()
       //console.log(res)
	      }).then(data=>{
       for (var i in data) {
	       this.scene_name.push(data[i].scene_name)
	       console.log( this.scene_name)
		         }  
          })
		 var url="/queryapplynumber"
		 fetch(url).then(res=>{
		 // this.tableData=res.data
		 return res.json()
		//console.log(res)
		 }).then(data=>{
		 for (var i in data) {
		this.applynumber.push(data[i].number)
		console.log( this.applynumber)
		}  
	})
	}
  }
}
</script>

<style>
</style>