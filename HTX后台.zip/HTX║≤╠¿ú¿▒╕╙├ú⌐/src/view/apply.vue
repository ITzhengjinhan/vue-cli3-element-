<template>
  <div class="wrapper">
    <article style="flex:1;padding:10px;">
      <el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item to="/home/index">首页</el-breadcrumb-item>
  <el-breadcrumb-item>报名管理</el-breadcrumb-item>
  <el-input v-model="input1" placeholder="活动名称搜索" style="margin:10px 0" @input="query"></el-input>
  <el-button
          size="mini"
           type="primary"
            @click="addapply"
          >添加</el-button>
	 <el-button
          size="mini"
           type="primary"
            @click="exportexcel"
          >导出</el-button>
</el-breadcrumb>

<el-table 
    :data="tableData"
    stripe
    style="width: 100%"
	id="out-table">


    <el-table-column
      prop="scene_id"
      label="活动编号"
      width="100">
    </el-table-column>

	<el-table-column
      prop="scene_name"
      label="活动名称"
      width="150">
    </el-table-column>

  <el-table-column
      prop="isapply" 
      label="状态（1：成功，0：失败）"
      width="350">
    </el-table-column>

    <el-table-column
      prop="phonenumber" 
      label="手机号码"
      width="350">
    </el-table-column>

   <el-table-column label="操作"
    width="150">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="Editapply(scope.$index, scope.row)">编辑</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="Deleteapply(scope.$index, scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
<!--
  分页
-->
  <div style="display:flex;justify-content:center">
  <el-pagination
  v-if="switch1"
  background
  layout="prev, pager, next"
  @current-change="getdata"
  :page-size=pagesize
  :total="total">
  </el-pagination>
  </div>

  <!--
  弹框
  -->
  <el-dialog
  :title="one?'编辑':'添加'"
  :visible.sync="dialogVisible"
  width="50%"
  >
  <!--
  表单
  -->
  <el-form ref="form" :model="form" label-width="80px">
  
  <el-form-item label="活动编号">
    <el-input v-model="form.scene_id"></el-input>
  </el-form-item>
  <el-form-item label="状态（1：成功，0：失败）">
    <el-input v-model="form.isapply"></el-input>
  </el-form-item>
  <el-form-item label="手机号">
    <el-input v-model="form.phonenumber"></el-input>
  </el-form-item>
  </el-form>
  <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="submit">确 定</el-button>
  </span>
</el-dialog>

 </article>
  </div>
</template>

<script>
import FileSaver from "file-saver";
import XLSX from "xlsx";
export default {
   inject:['reload'],
  components: {},
  props: {},
  data() {
      return {
        tableData: [],//数组变量
        pagesize:3,//每页显示个数选择器的选项设置
        total:10,//总条目数
        zero:0,//标记，测试
        one:'',//标记，区分添加还是编辑
        isdelete:'',
        dialogVisible: false,
        form: {
        phonenumber:'',
         apply_id:'',
         scene_id:'',
         isapply:''
          },
          status:'',
		  input1:'',//绑定输入内容
		  switch1:true//控制分页，搜索时不分页
      };
    },
    created(){
    this.getdata(1);//默认加载第一页
    },
    methods: {
    query(){
	 if(this.input1!=''){
	 console.log(this.input1)
	  var url="/queryapplybyinput?scene_name="+this.input1 
	  fetch(url).then(res=>{
	   // this.tableData=res.data 
	   return res.json()
	    //console.log(res)
		 }).then(data=>{
		 //console.log(data)
		   this.tableData=data
		   this.switch1=false  })
		   }else{
		    this.reload()
			}
		},
							  
    getdata(pageindex){
      
      //解决端口跨域问题
      console.log(pageindex)
      //这里的pagesize后面的值要与上面的一致
      var url="/pagingqueryapply?pageindex="+pageindex+"&&pagesize="+3
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.tableData=data
      })
      
      //获取数量
      var url="/queryapplynumbertotal"
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
         console.log(data[this.zero].count)
        this.total=data[this.zero].count
      })
    },
    //删除----------------------------
    Deleteapply(id,sceneobj){
     // console.log(sceneobj.scene_id) 
    this.$confirm('确定删除?', '系统提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          //是,先删除外键依赖
         
      var url="/admindeleteapplybyid?apply_id="+sceneobj.apply_id
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.isdelete=data.status
        if(this.isdelete=='ok'){
          this.$message({
          message: '删除成功',
          type: 'success'
        });
         //刷新页面
       this.reload()
      }
     
       
      })    
        //否
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
     },
    
     //添加---------------------------
     addapply(){
       this.one=''
       this.dialogVisible=true
     },
      submit(){

        //判断是添加还是编辑
        if(this.one){
          console.log(111)
        var scene=this.form
        var url="/admineditapply?scene_id="+scene.scene_id+"&&isapply="+scene.isapply+"&&phonenumber="+scene.phonenumber+"&&apply_id="+scene.apply_id
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        
      }).then(data=>{
        //console.log(data)
        this.status=data.status
        console.log(this.status)
         if(this.status=='ok'){
          this.$message({
          message: '修改成功',
          type: 'success'
        });
        this.reload()
      }
      //关闭弹窗
         this.dialogVisible=false
         
          })
        }else{
          //-------------添加
        console.log(this.form)
        var scene=this.form
        var url="/adminaddapply?scene_id="+scene.scene_id+"&&isapply="+scene.isapply+"&&phonenumber="+scene.phonenumber
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.status=data.status
         if(this.status=='ok'){
          this.$message({
          message: '添加成功',
          type: 'success'
        });
      
      }
      //关闭弹窗
         this.dialogVisible=false
          this.reload()
          })
        }
      },
      //-------------编辑
      Editapply(id,sceneobj){
        this.dialogVisible=true
        this.one=sceneobj
        this.form=sceneobj//将数据表填入input表单中
        this.yuanhaoma=sceneobj.phonenumber
        
      },
	  exportexcel() {
	  var wb = XLSX.utils.table_to_book(document.querySelector("#out-table"));
	  var wbout = XLSX.write(wb, {
	  bookType: "xlsx",
	  bookSST: true,
	  type: "array"
	  });
	  try {
	  FileSaver.saveAs(
	  new Blob([wbout], { type: "application/octet-stream" }),
	  "活动报名表.xlsx"
	  );
	  } catch (e) {
	  if (typeof console !== "undefined") 
	  console.log(e, wbout);
	  }
	  return wbout;
	  }
    }
  }
</script>
<style  scoped>
.wrapper{}
</style>