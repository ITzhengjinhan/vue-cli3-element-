﻿var express=require('express');
var router=express.Router();
const db = require('./database')
router.get('/outdex',function(req,res,next){
    res.send('outdex');
})
//---------------------景区模块
//第pageindex页显示pagesize多数据
 router.get('/pagingqueryscene', (req, res) => {
	var pagesize=req.query.pagesize;
	var pageindex=(req.query.pageindex-1)*pagesize
    console.dir(req.query)
    let sql='SELECT * FROM scene limit '+pageindex+','+pagesize
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
   router.get('/queryscenenumber', (req, res) => {
    let sql='SELECT count(1) as count FROM scene' 
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  
  
   router.get('/deletescene', (req, res) => {
    console.dir(req.query)
    var scene_id=req.query.scene_id
    let sql=`DELETE FROM scene  where scene_id=`+scene_id
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/editscene', (req, res) => {
    console.dir(req.query)
	var scene_id=req.query.scene_id
    var scene_name="'"+req.query.scene_name+"'"
	var scene_desc="'"+req.query.scene_desc+"'"
	var scene_address="'"+req.query.scene_address+"'"
	var scene_detail="'"+req.query.scene_detail+"'"
	var img="'"+req.query.img+"'"
	var start_time="'"+req.query.start_time+"'"
	var end_time="'"+req.query.end_time+"'"
	var price="'"+req.query.price+"'"
    let sql=`update scene set scene_name=`+scene_name+',scene_desc='+scene_desc+',scene_address='+scene_address+',scene_detail='
    +scene_detail+',img='+img+',start_time='+start_time+',end_time='+end_time+',price='+price +' where scene_id='+scene_id; 
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })//http://localhost:3000/editscene?scene_name=test&&scene_desc=test&&scene_detail=test&&img=test&&start_time=test&&end_time=test&&price=test&&scene_id=1
  
  router.get('/addscene', (req, res) => {
    console.dir(req.query)
    var scene_name="'"+req.query.scene_name+"'"
	var scene_desc="'"+req.query.scene_desc+"'"
	var scene_address="'"+req.query.scene_address+"'"
	var scene_detail="'"+req.query.scene_detail+"'"
	var img="'"+req.query.img+"'"
	var start_time="'"+req.query.start_time+"'"
	var end_time="'"+req.query.end_time+"'"
	var price="'"+req.query.price+"'"
    let sql=`INSERT INTO scene(scene_name,scene_desc,scene_address,scene_detail,img,start_time,end_time,price) VALUES(`
    +scene_name+','+scene_desc+','+scene_address+','+scene_detail+','+img+','+start_time+','+end_time+','+price+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })//http://localhost:3000/addscene?scene_name=test&&scene_desc=test&&scene_detail=test&&img=test&&start_time=test&&end_time=test&&price=test
  
  //---------------------博物馆模块
  router.get('/pagingquerymuseum', (req, res) => {
    var pagesize=req.query.pagesize;
	var pageindex=(req.query.pageindex-1)*pagesize
    console.dir(req.query)
    let sql='SELECT * FROM museum limit '+pageindex+','+pagesize
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  router.get('/querymuseumnumber', (req, res) => {
    let sql='SELECT count(1) as count FROM museum' 
    db.query(sql, (err, result) => {
      if(result==''){
        res.json({status:'error'})
      }else{
        res.json(result); }
    }); 
  }) 
  
  
  
   router.get('/deletemuseum', (req, res) => {
    console.dir(req.query)
    var exhibit_id=req.query.exhibit_id
    let sql=`DELETE FROM museum  where exhibit_id=`+exhibit_id
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[DELETE ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/editmuseum', (req, res) => {
    console.dir(req.query)
	var exhibit_id=req.query.exhibit_id
    var exhibit_name="'"+req.query.exhibit_name+"'"
	var exhibit_info="'"+req.query.exhibit_info+"'"
	var exhibit_info_en="'"+req.query.exhibit_info_en+"'"
	var exhibit_img="'"+req.query.exhibit_img+"'"
	//var scene_detail="'"+req.query.scene_detail+"'"
	
    let sql=`update museum set exhibit_name=`+exhibit_name+',exhibit_info='+exhibit_info+',exhibit_info_en='+exhibit_info_en+',exhibit_img='+exhibit_img+' where exhibit_id='+exhibit_id; 
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
  router.get('/addmuseum', (req, res) => {
    console.dir(req.query)
   	 var exhibit_id=req.query.exhibit_id
    	var exhibit_name="'"+req.query.exhibit_name+"'"
	var exhibit_info="'"+req.query.exhibit_info+"'"
	var exhibit_info_en="'"+req.query.exhibit_info_en+"'"
	var exhibit_img="'"+req.query.exhibit_img+"'"
    let sql=`INSERT INTO museum(exhibit_name,exhibit_info,exhibit_info_en,exhibit_img) VALUES(`
    +exhibit_name+','+exhibit_info+','+exhibit_info_en+','+exhibit_img+')';
    db.query(sql,(err, result)=> {
        if(err){
         console.log('[INSERT ERROR] - ',err.message);
         return;
        }           
       res.json({status:'ok'})    
    });
  })
  
module.exports=router;