module.exports = {
 devServer:{
  proxy:"http://39.97.116.84:3000"
 }
}

