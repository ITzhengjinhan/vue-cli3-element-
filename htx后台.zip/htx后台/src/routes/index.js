import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

export default new VueRouter({
    routes:[
      {
        path:"/",
        /*  ./与@/的区别
        ./是相同目录下的不同路径访问
        @/是src目录下的路径
        */
       //路由懒加载：更高效
        component:()=>import ('@/view/login.vue')
        
      },
      {
        path:"/home",
        component:()=>import ('@/view/home.vue'),
        children:[{
          path:"applyproject",
        component:()=>import ('@/view/applyproject.vue'),
        },
        {
          path:"museuminfo",
        component:()=>import ('@/view/museuminfo.vue'),
        },{
          path:"index",
        component:()=>import ('@/view/index.vue'),
        }]
      }
    ]
   }) 