import Vue from 'vue'
import App from './App.vue'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI);
Vue.config.productionTip = false
import router from './routes/index'

import echarts from 'echarts'
Vue.prototype.$echarts=echarts
 //技巧，用index命名的路由路径文件，上式可以简写成：import router from './routes'
new Vue({
  render: h => h(App),

  router//相当于router:router
  
}).$mount('#app')
