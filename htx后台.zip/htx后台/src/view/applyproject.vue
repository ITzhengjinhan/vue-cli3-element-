<template>
  <div class="wrapper">
    <article style="flex:1;padding:10px;">
      <el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item to="/home/index">首页</el-breadcrumb-item>
  <el-breadcrumb-item>项目活动管理</el-breadcrumb-item>
  <el-button
          size="mini"
          type="primary"
          @click="addscene"
          >添加</el-button>
</el-breadcrumb>

<el-table 
    :data="tableData"
    stripe
    style="width: 100%">

    <el-table-column
      prop="scene_id" 
      label="序号"
      width="50"><!--prop要和JSON中的属性对应-->
    </el-table-column>

    <el-table-column
      prop="scene_name"
      label="景点名称"
      width="100">
    </el-table-column>

  <el-table-column
      prop="scene_desc" 
      label="景点描述"
      width="150">
    </el-table-column>

  <el-table-column
      prop="scene_address"  
      label="景区地址"
      width="120">
    </el-table-column>

    <el-table-column
      prop="img" 
      label="景点图片"
      width="150"><!--prop要和JSON中的属性对应-->
      <template slot-scope="scope"><!--将字符串转换为图片的地址-->
        <img :src="scope.row.img" style="width:100px;height:80px">
      </template>
    </el-table-column>
    
    <el-table-column
      prop="start_time"  
      label="开始时间"
      width="150">
    </el-table-column>
   
   <el-table-column
      prop="end_time"  
      label="结束时间"
      width="150">
    </el-table-column>
     
     <el-table-column
      prop="price"  
      label="价格"
      width="100">
    </el-table-column>

    <el-table-column label="操作"
    width="150">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="Editscene(scope.$index, scope.row)">编辑</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="Deletescene(scope.$index, scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
<!--
  分页
-->
  <div style="display:flex;justify-content:center">
  <el-pagination
  background
  layout="prev, pager, next"
  @current-change="getdata"
  :page-size=pagesize
  :total="total">
  </el-pagination>
  </div>

  <!--
  弹框
  -->
  <el-dialog
  :title="one?'编辑':'添加'"
  :visible.sync="dialogVisible"
  width="50%"
  >
  <!--
  表单
  -->
  <el-form ref="form" :model="form" label-width="80px">
  <el-form-item label="景点名称">
    <el-input v-model="form.scene_name"></el-input>
  </el-form-item>
  <el-form-item label="景点描述">
    <el-input v-model="form.scene_desc"></el-input>
  </el-form-item>
  <el-form-item label="景点地址">
    <el-input v-model="form.scene_address"></el-input>
  </el-form-item>
  <el-form-item label="注意事项">
    <el-input v-model="form.scene_detail"></el-input>
  </el-form-item>
  <el-form-item label="景点图片">
    <el-input v-model="form.img"></el-input>
    请上传网络图片，<a href="https://imgchr.com/" target="_blank">点此生成</a>
  </el-form-item>
  <el-form-item label="活动时间">
    <el-col :span="11">
      <el-date-picker type="date" placeholder="选择日期" value-format="yyyy-MM-dd" v-model="form.start_time" style="width: 100%;"></el-date-picker>
    </el-col>
    <el-col class="line" :span="2">至</el-col>
    <el-col :span="11">
      <el-date-picker type="date" placeholder="选择日期" value-format="yyyy-MM-dd" v-model="form.end_time" style="width: 100%;"></el-date-picker>
    </el-col>
  </el-form-item>
  <el-form-item label="价格">
    <el-input v-model="form.price"></el-input>
  </el-form-item>
  </el-form>
  <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="submit">确 定</el-button>
  </span>
</el-dialog>

 </article>
  </div>
</template>

<script>
export default {
  components: {},
  props: {},
  data() {
      return {
        tableData: [],//数组变量
        pagesize:3,//每页显示个数选择器的选项设置
        total:10,//总条目数
        zero:0,//标记，测试
        one:'',//标记，区分添加还是编辑
        isdelete:'',
        dialogVisible: false,
        form: {
          scene_name: '',
          scene_desc:'',
          scene_address:'',
          scene_detail:'',
          img:'',
          start_time:'',
          end_time:'',
          price:''
          },
          isadd:''
      };
    },
    created(){
    this.getdata(1);//默认加载第一页
    },
    methods: {
    
    getdata(pageindex){
      
      //解决端口跨域问题
      console.log(pageindex)
      //这里的pagesize后面的值要与上面的一致
      var url="/pagingqueryscene?pageindex="+pageindex+"&&pagesize="+3
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.tableData=data
      })
      
      //获取数量
      var url="/queryscenenumber"
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
         console.log(data[this.zero].count)
        this.total=data[this.zero].count
      })
    },
    //删除----------------------------
    Deletescene(id,sceneobj){
     // console.log(sceneobj.scene_id)
    this.$confirm('确定删除?', '系统提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          //是
      var url="/deletescene?scene_id="+sceneobj.scene_id
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.isdelete=data.status
        if(this.isdelete=='ok'){
          this.$message({
          message: '删除成功',
          type: 'success'
        });
      }
      //刷新页面
        this.getdata(1)
       
      })
          
        //否
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
     },
     //添加---------------------------
     addscene(){
       this.one=''
       this.dialogVisible=true
     },
      submit(){

        //判断是添加还是编辑
        if(this.one){
          console.log(111)
        var scene=this.form
        var url="/editscene?scene_id="+scene.scene_id+"&&scene_name="+scene.scene_name+"&&scene_desc="+scene.scene_desc+"&&scene_address="+scene.scene_address+"&&scene_detail="+scene.scene_detail+"&&img="+scene.img+"&&start_time="+scene.start_time+"&&end_time="+scene.end_time+"&&price="+scene.price
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.isadd=data.status
         if(this.isadd=='ok'){
          this.$message({
          message: '修改成功',
          type: 'success'
        });
      }
      //关闭弹窗
         this.dialogVisible=false
         this.getdata(1)
          })
        }else{
        console.log(this.form)
        var scene=this.form
        var url="/addscene?scene_name="+scene.scene_name+"&&scene_desc="+scene.scene_desc+"&&scene_address="+scene.scene_address+"&&scene_detail="+scene.scene_detail+"&&img="+scene.img+"&&start_time="+scene.start_time+"&&end_time="+scene.end_time+"&&price="+scene.price
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.isadd=data.status
         if(this.isadd=='ok'){
          this.$message({
          message: '添加成功',
          type: 'success'
        });
      }
      //关闭弹窗
         this.dialogVisible=false
         this.getdata(1)
          })
        }
      },
      //-------------编辑
      Editscene(id,sceneobj){
        this.dialogVisible=true
        this.one=sceneobj
        this.form=sceneobj
      }
    }
  }
</script>
<style  scoped>
.wrapper{}
</style>