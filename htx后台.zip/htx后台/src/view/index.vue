<template>
  <div class="wrapper">
   <div style="margin-left:20em;margin-top:6vh;position:absolute"><h2>欢迎来到武洋花天下后台管理系统</h2></div>
	<div id="myChart" :style="{width: '400px', height: '400px',marginLeft:'20em',marginTop:'20vh',position:'absolute'}"></div>
    </div>
</template>
<script>
export default {
  name: 'echarts',
  data () {
    return {
      
    }
  },
  mounted(){
    this.drawLine();
  },
  methods: {
    drawLine(){
        // 基于准备好的dom，初始化echarts实例
        let myChart = this.$echarts.init(document.getElementById('myChart'))
        // 绘制图表
        myChart.setOption({
            title: { text: '报名项目人数' },
            tooltip: {},
            xAxis: {
                data: ["吊桥","垂钓","采茶花","水上观光","极速滑行"]
            },
            yAxis: {},
            series: [{
                name: '人数',
                type: 'bar',
                data: [5, 20, 36, 10, 10, 20]
            }]
        });
    }
  }
}
</script>

<style>
</style>