<template>
  <div class="wrapper">
    <article style="flex:1;padding:10px;">
      <el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item to="/home/index">首页</el-breadcrumb-item>
  <el-breadcrumb-item>博物馆信息管理</el-breadcrumb-item>
  <el-button
          size="mini"
           type="primary"
            @click="addmuseum"
          >添加</el-button>
</el-breadcrumb>

<el-table 
    :data="tableData"
    stripe
    style="width: 100%">

    <el-table-column
      prop="exhibit_id" 
      label="序号"
      width="150"><!--prop要和JSON中的属性对应-->
    </el-table-column>

    <el-table-column
      prop="exhibit_name"
      label="文物名称"
      width="150">
    </el-table-column>

  <el-table-column
      prop="exhibit_info" 
      label="文物描述"
      width="250">
    </el-table-column>

    <el-table-column
      prop="exhibit_info_en" 
      label="英文描述"
      width="250">
    </el-table-column>

    <el-table-column
      prop="exhibit_img" 
      label="文物图片"
      width="150"><!--prop要和JSON中的属性对应-->
      <template slot-scope="scope"><!--将字符串转换为图片的地址-->
        <img :src="scope.row.exhibit_img" style="width:100px;height:80px">
      </template>
    </el-table-column>

   <el-table-column label="操作"
    width="150">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="Editmuseum(scope.$index, scope.row)">编辑</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="Deletemuseum(scope.$index, scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
<!--
  分页
-->
  <div style="display:flex;justify-content:center">
  <el-pagination
  background
  layout="prev, pager, next"
  @current-change="getdata"
  :page-size=pagesize
  :total="total">
  </el-pagination>
  </div>

  <!--
  弹框
  -->
  <el-dialog
  :title="one?'编辑':'添加'"
  :visible.sync="dialogVisible"
  width="50%"
  >
  <!--
  表单
  -->
  <el-form ref="form" :model="form" label-width="80px">
  <el-form-item label="文物名称">
    <el-input v-model="form.exhibit_name"></el-input>
  </el-form-item>
  <el-form-item label="文物描述">
    <el-input v-model="form.exhibit_info"></el-input>
  </el-form-item>
  <el-form-item label="英文描述">
    <el-input v-model="form.exhibit_info_en"></el-input>
  </el-form-item>
  <el-form-item label="文物图片">
    <el-input v-model="form.exhibit_img"></el-input>
    请上传网络图片，<a href="https://imgchr.com/" target="_blank">点此生成</a>
  </el-form-item>
  </el-form>
  <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="submit">确 定</el-button>
  </span>
</el-dialog>

 </article>
  </div>
</template>

<script>
export default {
  components: {},
  props: {},
  data() {
      return {
        tableData: [],//数组变量
        pagesize:3,//每页显示个数选择器的选项设置
        total:10,//总条目数
        zero:0,//标记，测试
        one:'',//标记，区分添加还是编辑
        isdelete:'',
        dialogVisible: false,
        form: {
         exhibit_name:'',
         exhibit_info:'',
         exhibit_info_en:'',
         exhibit_img:'',
          },
          isadd:''
      };
    },
    created(){
    this.getdata(1);//默认加载第一页
    },
    methods: {
    
    getdata(pageindex){
      
      //解决端口跨域问题
      console.log(pageindex)
      //这里的pagesize后面的值要与上面的一致
      var url="/pagingquerymuseum?pageindex="+pageindex+"&&pagesize="+3
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.tableData=data
      })
      
      //获取数量
      var url="/querymuseumnumber"
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
         console.log(data[this.zero].count)
        this.total=data[this.zero].count
      })
    },
    //删除----------------------------
    Deletemuseum(id,sceneobj){
     // console.log(sceneobj.scene_id)
    this.$confirm('确定删除?', '系统提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          //是
      var url="/deletemuseum?exhibit_id="+sceneobj.exhibit_id
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.isdelete=data.status
        if(this.isdelete=='ok'){
          this.$message({
          message: '删除成功',
          type: 'success'
        });
      }
      //刷新页面
        this.getdata(1)
       
      })
          
        //否
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
     },
     //添加---------------------------
     addmuseum(){
       this.one=''
       this.dialogVisible=true
     },
      submit(){

        //判断是添加还是编辑
        if(this.one){
          console.log(111)
        var scene=this.form
        var url="/editmuseum?exhibit_id="+scene.exhibit_id+"&&exhibit_name="+scene.exhibit_name+"&&exhibit_info="+scene.exhibit_info+"&&exhibit_info_en="+scene.exhibit_info_en+"&&exhibit_img="+scene.exhibit_img
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.isadd=data.status
         if(this.isadd=='ok'){
          this.$message({
          message: '修改成功',
          type: 'success'
        });
      }
      //关闭弹窗
         this.dialogVisible=false
         this.getdata(1)
          })
        }else{
        console.log(this.form)
        var scene=this.form
        var url="/addmuseum?exhibit_name="+scene.exhibit_name+"&&exhibit_info="+scene.exhibit_info+"&&exhibit_info_en="+scene.exhibit_info_en+"&&exhibit_img="+scene.exhibit_img
      fetch(url).then(res=>{
        // this.tableData=res.data
        return res.json()
        //console.log(res)
      }).then(data=>{
        //console.log(data)
        this.isadd=data.status
         if(this.isadd=='ok'){
          this.$message({
          message: '添加成功',
          type: 'success'
        });
      }
      //关闭弹窗
         this.dialogVisible=false
         this.getdata(1)
          })
        }
      },
      //-------------编辑
      Editmuseum(id,sceneobj){
        this.dialogVisible=true
        this.one=sceneobj
        this.form=sceneobj
      }
    }
  }
</script>
<style  scoped>
.wrapper{}
</style>