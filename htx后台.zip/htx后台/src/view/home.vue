<template>
<div id="app">
    <header style="display:flex;background:#545c64; align-items:center;justify-content:space-between" >
    <div style="color:white;padding-left:30px;font-size:30px">花天下景区后台</div>
<el-menu
  router='true'
  :default-active="activeIndex2"
  class="el-menu-demo"
  mode="horizontal"
  @select="handleSelect"
  background-color="#545c64"
  text-color="#fff"
  active-text-color="#0000ff">
  <el-menu-item index="0" ><h2 style="margin-top:-1px;font-color:#000000">用户：管理员</h2></el-menu-item>
  <el-menu-item index="1">消息中心</el-menu-item>
  <el-submenu index="3">
    <template slot="title">账号管理</template>
    <el-menu-item index="/" to="/">退出登录</el-menu-item>
  </el-submenu>
  <el-menu-item index="4"><a href="https://www.ele.me" target="_blank">开发反馈</a></el-menu-item>
  
</el-menu>
</header>
  <section style="height:calc(100vh - 60px); display:flex;">
    <nav style="width:202px;height:700px;background:#545c64">
    <el-menu
      default-active="1"
      class="el-menu-vertical-demo"
      @open="handleOpen"
      @close="handleClose"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#0000ff">
      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>景区管理</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="1-1"><router-link to="/home/applyproject">项目活动管理</router-link></el-menu-item>
          <el-menu-item index="1-2"><router-link to="/HelloWorld">景区信息管理</router-link></el-menu-item>
          <el-menu-item index="1-3"><router-link to="/home/museuminfo">博物馆信息管理</router-link></el-menu-item>
         
        </el-menu-item-group>
      </el-submenu>
      <el-menu-item index="2">
        <i class="el-icon-menu"></i>
        <span slot="title">用户管理</span>
      </el-menu-item>
      <el-menu-item index="3" >
        <i class="el-icon-document"></i>
        <span slot="title">订单信息</span>
      </el-menu-item>
      <el-menu-item index="4">
        <i class="el-icon-setting"></i>
        <span slot="title">游戏管理</span>
      </el-menu-item>
    </el-menu>
  </el-col>
    </nav>
  <router-view/> 
  </section>
	
  </div>
</template>
<script>
export default {
  name: 'echarts',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  mounted(){
    this.drawLine();
  },
  methods: {
   
  }
}
</script>

<style>
</style>